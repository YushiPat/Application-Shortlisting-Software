from tkinter import Tk, Label, Button
from matplotlib import pyplot as plt
import mysql.connector

mydb = mysql.connector.connect(
  host="localhost",
  user="root",
  passwd="Akis.123",
  database="Application"
)

mycursor = mydb.cursor()

class App:
    def __init__(self, master):
        self.master = master
        master.title("Queries")

        self.label = Label(master, text="Select any one")
        self.label.pack()

        self.sat_button = Button(master, text="SAT toppers", command=self.sat)
        self.sat_button.pack()

        self.sats_button = Button(master, text="SAT Subject toppers", command=self.sats)
        self.sats_button.pack()

        self.overall_button = Button(master, text="High Overall scores", command=self.overall)
        self.overall_button.pack()

        self.nat_button = Button(master, text="Nationality", command=self.nat)
        self.nat_button.pack()

        self.extra_button = Button(master, text="Extracurricular", command=self.extra)
        self.extra_button.pack()

        self.age_button = Button(master, text="Age", command=self.age)
        self.age_button.pack()


    def sat(self):
        mycursor.execute("SELECT Fullname, SAT FROM resumemain order by SAT desc")
        l=[]
        for i in range(5):
            myresult1 = mycursor.fetchone()
            a=list(myresult1)
            l.append(a)
            print (myresult1)
        print (l)
        l2=[]
        l3=[]
        for i in range(0,len(l)):
            l2.append(l[i][0])
        y=l2
        for i in range(0,len(l)):
            l3.append(l[i][1])
        z=l3
        plt.plot(y,z,label="SAT SCORE TOPPERS")
        plt.xlabel("NAMES")
        plt.ylabel("SAT SCORES")

        plt.legend()
        plt.show()
                       

    def sats(self):
        import numpy as np
        mycursor.execute("SELECT Fullname, SATSubject FROM resumemain order by SATSubject desc")
        l=[]
        for i in range(5):
            myresult1 = mycursor.fetchone()
            a=list(myresult1)
            l.append(a)
            print (myresult1)
        print (l)
                
        l2=[]
        l3=[]
        for i in range(0,len(l)):
            l2.append(l[i][0])
        y=l2
        for i in range(0,len(l)):
            l3.append(l[i][1])
        z=l3
        plt.plot(y,z,label="SAT SUBJECT SCORE TOPPERS")
        plt.xlabel("NAMES")
        plt.ylabel("SAT SUBJECT SCORES")
        plt.bar(y,z,width=0.5)
        
        plt.legend()
        plt.show()

        
    def nat(self):
        mycursor.execute("SELECT Fullname, Nationality FROM resumemain order by classrank asc")
        n=input("Which nationality do you prefer?")
        l=[]
        myresult1 = mycursor.fetchall()
        for i in myresult1:
            x=list(i)
            for j in x:
                if j==n:
                    l.append(i)
        print (l)
    
    def overall(self):
        mycursor.execute("SELECT Fullname, Overall FROM resumemain order by Overall desc")
        l=[]
        for i in range(5):
            myresult1 = mycursor.fetchone()
            a=list(myresult1)
            l.append(a)
            print (myresult1)
        print (l)

        l2=[]
        l3=[]
        for i in range(0,len(l),2):
            l2.append(l[i])
        y=l2
        for i in range(1,len(l),2):
            l3.append(l[i])
        z=l3
        plt.bar(y,z,label="OVERALL SUBJECT TOPPERS")
        plt.xlabel("NAMES")
        plt.ylabel("OVERALL SCORES")
        
        plt.legend()
        plt.show()


    def extra(self):
        mycursor.execute("select count(Fullname) from resumemain")
        myre=mycursor.fetchone()
        print (myre)
        q=int(myre[0])
        print (q)
        mycursor.execute("select Fullname from resumemain")
        l2=[]
        c=input("Enter what criteria you want to select on:")
        for i in range(q):
            myresult=mycursor.fetchone()
            x=str(myresult[0])
            a=x.split()
            l2.append(a[0])

        print (l2)
        L=[]
        for i in range(len(l2)):
            
            q=str(l2[i])+'.txt'
            print (q)
            f=open(q , "r")
            f1=f.read()
            if c in f1:
                L.append(l2[i])
            else:
                continue
        print (c,':',L)

        for i in L:
            q=str(i)+'.txt'
            f=open(q , "r")
            f1=f.read()
            print (f1)
                    


                    
    def age(self):
        mycursor.execute("SELECT Fullname, DOB FROM resumemain order by DOB")
        l=[]
        for i in range(5):
            myresult1 = mycursor.fetchone()
            a=list(myresult1)
            l.append(a)
            print (myresult1)
        print (l)

        
        

root = Tk()
App(root)

